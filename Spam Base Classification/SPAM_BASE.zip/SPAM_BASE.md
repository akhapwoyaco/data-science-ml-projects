---
title: 'SPAM BASE CLASSIFICATION'
format: 
    docx: 
        toc: true
        section-numbers: true
        fig-width: 10
        fig-height: 9
execute: 
    echo: false
    warning: false
---
# Introduction

Email as a means of digital communication has been in use since the internet boom, both formally and informally. Companies use email as a means to provide further updates to their customers concerning products. However, emails have been misused, spam emails have been flooding into email users inbox with fake advertisements leading to phony sites, with links containing phishing links and pyramid schemes.

The need to sieve genuine from spam email guides our analysis, with the use of datasets on frequently occuring wordings from both spam and non spam email to build a spam classification model. The data is pre-processed, and used to train classification models that in turn are used on new data for classification purposes. The efficiency of the model is based upon the accuracy of correct classification of observations into either of the spam or non spam category.


```python

```

# Corpus Preparation


```python

```

## Data

The [Spambase Data Set](https://archive.ics.uci.edu/ml/datasets/Spambase) was obtained from the [UCI Machine Learning Repository](https://archive.ics.uci.edu/ml/datasets/). The data is characterised by: 

1. Number of observations: 4601
2. Number of features (attributes): 57


```python
import pandas as pd # data manipulation
import numpy as np # data manipulation
import re # clean the attribute names
import matplotlib.pyplot as plt # plotting
import seaborn as sns # plotting
import warnings
warnings.filterwarnings('ignore')
```


```python

```

### Data Import

The data was loaded as **spam_base_data** into the workspace from the **spambase.data** file, and attribute names assigned from the **spambase.names** data file, loaded as **attribute_names**.  


```python

```


```python
# read spam data attribute names into local workspace
with open('spambase.names') as f:
 text = f.read()
attribute_names = re.findall(r'\n(\w*_?\W?):', text)

# read in data, with no headers and column names as previousy imported column names 
spam_base_data = pd.read_csv('spambase.data', header=None, names = attribute_names +['spam'])
```


```python
spam_base_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word_freq_make</th>
      <th>word_freq_address</th>
      <th>word_freq_all</th>
      <th>word_freq_3d</th>
      <th>word_freq_our</th>
      <th>word_freq_over</th>
      <th>word_freq_remove</th>
      <th>word_freq_internet</th>
      <th>word_freq_order</th>
      <th>word_freq_mail</th>
      <th>...</th>
      <th>char_freq_;</th>
      <th>char_freq_(</th>
      <th>char_freq_[</th>
      <th>char_freq_!</th>
      <th>char_freq_$</th>
      <th>char_freq_#</th>
      <th>capital_run_length_average</th>
      <th>capital_run_length_longest</th>
      <th>capital_run_length_total</th>
      <th>spam</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.00</td>
      <td>0.64</td>
      <td>0.64</td>
      <td>0.0</td>
      <td>0.32</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.000</td>
      <td>0.0</td>
      <td>0.778</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.756</td>
      <td>61</td>
      <td>278</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.21</td>
      <td>0.28</td>
      <td>0.50</td>
      <td>0.0</td>
      <td>0.14</td>
      <td>0.28</td>
      <td>0.21</td>
      <td>0.07</td>
      <td>0.00</td>
      <td>0.94</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.132</td>
      <td>0.0</td>
      <td>0.372</td>
      <td>0.180</td>
      <td>0.048</td>
      <td>5.114</td>
      <td>101</td>
      <td>1028</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.06</td>
      <td>0.00</td>
      <td>0.71</td>
      <td>0.0</td>
      <td>1.23</td>
      <td>0.19</td>
      <td>0.19</td>
      <td>0.12</td>
      <td>0.64</td>
      <td>0.25</td>
      <td>...</td>
      <td>0.01</td>
      <td>0.143</td>
      <td>0.0</td>
      <td>0.276</td>
      <td>0.184</td>
      <td>0.010</td>
      <td>9.821</td>
      <td>485</td>
      <td>2259</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.63</td>
      <td>0.00</td>
      <td>0.31</td>
      <td>0.63</td>
      <td>0.31</td>
      <td>0.63</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.137</td>
      <td>0.0</td>
      <td>0.137</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.537</td>
      <td>40</td>
      <td>191</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.00</td>
      <td>0.0</td>
      <td>0.63</td>
      <td>0.00</td>
      <td>0.31</td>
      <td>0.63</td>
      <td>0.31</td>
      <td>0.63</td>
      <td>...</td>
      <td>0.00</td>
      <td>0.135</td>
      <td>0.0</td>
      <td>0.135</td>
      <td>0.000</td>
      <td>0.000</td>
      <td>3.537</td>
      <td>40</td>
      <td>191</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 58 columns</p>
</div>




```python

```


```python
print('The Spam Base data contains %d observations and %d columns, inclusive of 57 attributes and the column attribute that \n denotes whether the e-mail was considered spam (1) or not (0).' % spam_base_data.shape)
```

    The Spam Base data contains 4601 observations and 58 columns, inclusive of 57 attributes and the column attribute that 
     denotes whether the e-mail was considered spam (1) or not (0).
    


```python

```

### Check Duplicated Observations


```python
#checking whether our data has duplicated values
count_of_duplicated = spam_base_data.duplicated().sum()
count_of_duplicated
```




    np.int64(391)




```python
print("There are %d count of duplicated observations, of the %d observations." % (count_of_duplicated, spam_base_data.shape[0]))
```

    There are 391 count of duplicated observations, of the 4601 observations.
    

Duplicated observations will be dropped from the dataset.


```python
#dropping duplicated values
spam_base = spam_base_data.drop_duplicates(subset=None, keep = 'first', inplace = False)
```


```python
print('The Spam Base data after dropping duplicates contains %d observations and %d columns, inclusive of 57 attributes and the column attribute that \n denotes whether the e-mail was considered spam (1) or not (0).' % spam_base.shape)
```

    The Spam Base data after dropping duplicates contains 4210 observations and 58 columns, inclusive of 57 attributes and the column attribute that 
     denotes whether the e-mail was considered spam (1) or not (0).
    


```python

```

### Check Missing Data Points


```python
#checking for null values
spam_base.isna().any().any()
```




    np.False_



There are no missing data points in the data.


```python

```

### Convert spam column to categorical

The final column **spam**, that is nominal, taking up binary values is converted to categorical as it denotes whether the e-mail was considered spam (1) or not (0).


```python
# convert cst column to categorical
spam_base.spam = pd.Categorical(
       spam_base.spam, categories = [0, 1], ordered = True)
print(spam_base['spam'].unique())
print(spam_base['spam'].value_counts())
```

    [1, 0]
    Categories (2, int64): [0 < 1]
    spam
    0    2531
    1    1679
    Name: count, dtype: int64
    


```python

```

### Describe Data


```python
#checking the description our the dataset we have for analysis
spam_base.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>word_freq_make</th>
      <th>word_freq_address</th>
      <th>word_freq_all</th>
      <th>word_freq_3d</th>
      <th>word_freq_our</th>
      <th>word_freq_over</th>
      <th>word_freq_remove</th>
      <th>word_freq_internet</th>
      <th>word_freq_order</th>
      <th>word_freq_mail</th>
      <th>...</th>
      <th>word_freq_conference</th>
      <th>char_freq_;</th>
      <th>char_freq_(</th>
      <th>char_freq_[</th>
      <th>char_freq_!</th>
      <th>char_freq_$</th>
      <th>char_freq_#</th>
      <th>capital_run_length_average</th>
      <th>capital_run_length_longest</th>
      <th>capital_run_length_total</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>...</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
      <td>4210.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.104366</td>
      <td>0.112656</td>
      <td>0.291473</td>
      <td>0.063078</td>
      <td>0.325321</td>
      <td>0.096656</td>
      <td>0.117475</td>
      <td>0.108000</td>
      <td>0.091860</td>
      <td>0.248420</td>
      <td>...</td>
      <td>0.034746</td>
      <td>0.040403</td>
      <td>0.144048</td>
      <td>0.017376</td>
      <td>0.281136</td>
      <td>0.076057</td>
      <td>0.045798</td>
      <td>5.383896</td>
      <td>52.139905</td>
      <td>291.181948</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.300005</td>
      <td>0.454260</td>
      <td>0.515719</td>
      <td>1.352487</td>
      <td>0.687805</td>
      <td>0.276030</td>
      <td>0.397284</td>
      <td>0.410282</td>
      <td>0.282144</td>
      <td>0.656638</td>
      <td>...</td>
      <td>0.298521</td>
      <td>0.252533</td>
      <td>0.274256</td>
      <td>0.105731</td>
      <td>0.843321</td>
      <td>0.239708</td>
      <td>0.435925</td>
      <td>33.147358</td>
      <td>199.582168</td>
      <td>618.654838</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.627500</td>
      <td>7.000000</td>
      <td>40.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.073000</td>
      <td>0.000000</td>
      <td>0.016000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>2.297000</td>
      <td>15.000000</td>
      <td>101.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.440000</td>
      <td>0.000000</td>
      <td>0.410000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.190000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.194000</td>
      <td>0.000000</td>
      <td>0.331000</td>
      <td>0.053000</td>
      <td>0.000000</td>
      <td>3.706750</td>
      <td>44.000000</td>
      <td>273.750000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>4.540000</td>
      <td>14.280000</td>
      <td>5.100000</td>
      <td>42.810000</td>
      <td>10.000000</td>
      <td>5.880000</td>
      <td>7.270000</td>
      <td>11.110000</td>
      <td>5.260000</td>
      <td>18.180000</td>
      <td>...</td>
      <td>10.000000</td>
      <td>4.385000</td>
      <td>9.752000</td>
      <td>4.081000</td>
      <td>32.478000</td>
      <td>6.003000</td>
      <td>19.829000</td>
      <td>1102.500000</td>
      <td>9989.000000</td>
      <td>15841.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 57 columns</p>
</div>




```python

```

### EDA

#### Correlation Plot

Correlation analysis provides the linear relation between attributes. Majority of the variables are weakly correlated.


```python
#checking between our datasets
correlation_mat = spam_base.corr()
```


```python
# get the highy correlated variables
corr_mat1 = correlation_mat.stack().reset_index() #convert to long format
corr_mat1.columns = ['Var1', 'Var2', 'Cor'] # set column names
corr_mat1[corr_mat1.Cor != 1].drop_duplicates(
    # remove duplicated corr values
    subset = ['Cor'], keep = 'first', inplace = False).sort_values(
    # sort by corr
    by = 'Cor', ascending = False).head(20) # get top 20 highly correlated
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Var1</th>
      <th>Var2</th>
      <th>Cor</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1831</th>
      <td>word_freq_857</td>
      <td>word_freq_415</td>
      <td>0.994875</td>
    </tr>
    <tr>
      <th>1837</th>
      <td>word_freq_857</td>
      <td>word_freq_direct</td>
      <td>0.824206</td>
    </tr>
    <tr>
      <th>1953</th>
      <td>word_freq_415</td>
      <td>word_freq_direct</td>
      <td>0.820837</td>
    </tr>
    <tr>
      <th>1771</th>
      <td>word_freq_telnet</td>
      <td>word_freq_857</td>
      <td>0.681542</td>
    </tr>
    <tr>
      <th>1773</th>
      <td>word_freq_telnet</td>
      <td>word_freq_415</td>
      <td>0.678672</td>
    </tr>
    <tr>
      <th>1833</th>
      <td>word_freq_857</td>
      <td>word_freq_technology</td>
      <td>0.672118</td>
    </tr>
    <tr>
      <th>1949</th>
      <td>word_freq_415</td>
      <td>word_freq_technology</td>
      <td>0.668905</td>
    </tr>
    <tr>
      <th>1779</th>
      <td>word_freq_telnet</td>
      <td>word_freq_direct</td>
      <td>0.641129</td>
    </tr>
    <tr>
      <th>1775</th>
      <td>word_freq_telnet</td>
      <td>word_freq_technology</td>
      <td>0.621127</td>
    </tr>
    <tr>
      <th>2069</th>
      <td>word_freq_technology</td>
      <td>word_freq_direct</td>
      <td>0.620903</td>
    </tr>
    <tr>
      <th>1713</th>
      <td>word_freq_labs</td>
      <td>word_freq_857</td>
      <td>0.611890</td>
    </tr>
    <tr>
      <th>1715</th>
      <td>word_freq_labs</td>
      <td>word_freq_415</td>
      <td>0.609025</td>
    </tr>
    <tr>
      <th>1717</th>
      <td>word_freq_labs</td>
      <td>word_freq_technology</td>
      <td>0.579540</td>
    </tr>
    <tr>
      <th>1712</th>
      <td>word_freq_labs</td>
      <td>word_freq_telnet</td>
      <td>0.557627</td>
    </tr>
    <tr>
      <th>1721</th>
      <td>word_freq_labs</td>
      <td>word_freq_direct</td>
      <td>0.555914</td>
    </tr>
    <tr>
      <th>1600</th>
      <td>word_freq_650</td>
      <td>word_freq_85</td>
      <td>0.542526</td>
    </tr>
    <tr>
      <th>1601</th>
      <td>word_freq_650</td>
      <td>word_freq_technology</td>
      <td>0.513107</td>
    </tr>
    <tr>
      <th>1595</th>
      <td>word_freq_650</td>
      <td>word_freq_labs</td>
      <td>0.513077</td>
    </tr>
    <tr>
      <th>1417</th>
      <td>word_freq_hp</td>
      <td>word_freq_hpl</td>
      <td>0.504655</td>
    </tr>
    <tr>
      <th>1597</th>
      <td>word_freq_650</td>
      <td>word_freq_857</td>
      <td>0.500121</td>
    </tr>
  </tbody>
</table>
</div>



The frequency across words 85, 67, 650, 857, 415, direct, telnet and technology may be attributed to presence of phone numbers or addresses associated to given labs providing certain technological products, as such given the lucrativeness of blue chip companies, theor associated key words may have been frequently used in spam or no spam emails.


```python

```


```python
# corr plot
plt.figure(figsize=(16, 12))
ax = sns.heatmap(
    correlation_mat, xticklabels = correlation_mat.columns, 
    yticklabels = correlation_mat.columns, 
    cmap = sns.diverging_palette(220, 10, as_cmap = True), 
    square=True, linewidths=.1)
ax.set(title="Correlation heatmap");
```


    
![png](output_43_0.png)
    



```python

```

#### Average Word, Char and Capital Run Distributions

Word Frequency


```python
fig, axes = plt.subplots(1, 1)
fig.set_figheight(40)
fig.set_figwidth(10)
average_word_char_cap = pd.melt(
    spam_base[spam_base.columns[spam_base.columns.to_series().str.contains(r'word|spam')]], 
    id_vars = ['spam'])
sns.boxplot(y = 'variable', x = 'value', hue = 'spam', data = average_word_char_cap, 
            orient = 'h')
plt.show()
```


    
![png](output_47_0.png)
    


Character Frequency


```python
char_spam_data = spam_base[spam_base.columns[spam_base.columns.to_series().str.contains(r'char|spam')]]
fig, axes = plt.subplots(6, 1)
fig.set_figheight(20)
fig.set_figwidth(10)
sns.boxplot(x = 'char_freq_;', hue = 'spam', 
                 y = 'spam', data = char_spam_data, orient = 'h',
                 ax = axes[0]).set(title = 'char_freq_;', xlabel = '')
sns.boxplot(x = 'char_freq_(', hue = 'spam',
                 y = 'spam', data = char_spam_data, orient = 'h', 
                 ax = axes[1]).set(title = 'char_freq_(', xlabel = '')
sns.boxplot(x = 'char_freq_[', hue = 'spam',
                 y = 'spam', data = char_spam_data, orient = 'h', 
                 ax = axes[2]).set(xlabel = '', title = 'char_freq_[')
sns.boxplot(x = 'char_freq_!', hue = 'spam',
                 y = 'spam', data = char_spam_data, orient = 'h', 
                 ax = axes[3]).set(title = 'char_freq_!', xlabel = '')
sns.boxplot(x = 'char_freq_$', hue = 'spam',
                 y = 'spam', data = char_spam_data, orient = 'h', 
                 ax = axes[4]).set(xlabel = '', title = 'char_freq_$')
sns.boxplot(x = 'char_freq_#', hue = 'spam',
                 y = 'spam', data = char_spam_data, orient = 'h', 
                 ax = axes[5]).set(title = 'char_freq_#', xlabel = '')
plt.show()
```


    
![png](output_49_0.png)
    


Capita Run Length


```python
capital_spam_data = spam_base[spam_base.columns[spam_base.columns.to_series().str.contains(r'cap|spam')]]
fig, axes = plt.subplots(3, 1)
fig.set_figheight(10)
fig.set_figwidth(10)
sns.boxplot(x = 'capital_run_length_average', hue = 'spam', 
                 y = 'spam', data = capital_spam_data, orient = 'h',
                 ax = axes[0]).set(title = 'capital_run_length_average', xlabel = '')
sns.boxplot(x = 'capital_run_length_longest', hue = 'spam',
                 y = 'spam', data = capital_spam_data, orient = 'h', 
                 ax = axes[1]).set(title = 'capital_run_length_longest', xlabel = '')
sns.boxplot(x = 'capital_run_length_total', hue = 'spam',
                 y = 'spam', data = capital_spam_data, orient = 'h', 
                 ax = axes[2]).set(xlabel = '', title = 'capital_run_length_total')
plt.show()
```


    
![png](output_51_0.png)
    


There appears to be extreme values within our data variables, majorly among the spma = 1 categories.


```python

```

# Solution Methodology

Data modelling phase will involve:
    
1. Extended corpus preparation through pre-processing of the independent attribute variables: The process will involve the scaling of all of numerical variables with the sole aim of standardizing the variables that vary with regard to units of measurement.
2. The data is split into train (80%) and test (20%), as a percentage of whole data, with indices of observation in either of the data sets selected randomly. The train data (80%) is used for training the model while 20% to test model perfomance through evaluation metrics, in our case accuracy.
3. The binary nature of the response variable guides the selection of the models of interest: K Nearest Neighbors (K-nn) and Decision Trees.
4. Evaluation criteria and model evaluation encompasses the training of models using hypertuned parameters on training data sets and comparing the perfomance of the models on new dataset, the test data.


```python

```

## Data Preprocessing


```python
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
```


```python
# Standardardize the data
spam_base_model_dataset = spam_base.copy()
spam_base_model_dataset.iloc[:, 0:57] = MinMaxScaler().fit_transform(spam_base_model_dataset.iloc[:, 0:57])
```

## Data Split


```python
# set random seed for reproducibility
np.random.seed(12345)
train_index = np.random.rand(len(spam_base_model_dataset)) < 0.8
# split the dataset into train and test sets
train_data = spam_base_model_dataset.iloc[train_index,:]
test_data = spam_base_model_dataset.iloc[~train_index,:]
# get predictors of train and test
X_train = train_data.copy()
X_test = test_data.copy()
# get response train and test
y_train = train_data.copy()
y_test = test_data.copy()
# drop response from predictor variables
X_train = X_train.drop(['spam'],axis=1)
X_test = X_test.drop(['spam'],axis=1)
# get responce train and test
y_train = y_train['spam']
y_test = y_test['spam']
print('Training Data Set Predictor shape: ', X_train.shape, 'Response Variable:', y_train.shape)
print('Testing Data Set Predictor shape: ', X_test.shape, 'Response Variable:' , y_test.shape)
```

    Training Data Set Predictor shape:  (3366, 57) Response Variable: (3366,)
    Testing Data Set Predictor shape:  (844, 57) Response Variable: (844,)
    


```python

```

## Modelling


```python
from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score
from sklearn.model_selection import cross_validate, cross_val_predict
from sklearn.metrics import confusion_matrix
```


```python

```

### K Neares Neighbors (knn)


```python
# Model
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import GridSearchCV
# model initialisation
knn = KNeighborsClassifier()
```

The KNN model is initialised, by the _KNeighborsClassifier()_ method of scikit learn module. Hyperparameter tuning or optimization is undertaken to choosing a set of optimal hyperparameters for the KNN learning on parameters: 

1. The number of neighbors to use: Selected as 2 given the binary nature of outcome spam.
2. The weight function to be used in prediction, with selection from the 'uniform', for equal weighing of points within a neighborhood and 'distance', for weighing based on inverse of distance within neighborhood.
3. The metric to be used for computation of the distance: 'minkowski', 'euclidean','manhattan'.

Other values passed to the other parameters are learned over the course of training the model. A KNN model is then fit, with the best parameters.


```python
# Hypertuning parameters
grid_params_knn = { 'n_neighbors' : list(range(2, 20)),
               'weights' : ['uniform','distance'],
               'metric' : ['minkowski','euclidean','manhattan']}
gscv_knn = GridSearchCV(KNeighborsClassifier(), grid_params_knn, verbose = 1, cv=4, n_jobs = -1)
```


```python
# fit knn model on train data
gsearchcv_knn = gscv_knn.fit(X_train, y_train)
# hyperparameters from best score
gsearchcv_knn.best_params_
```

    Fitting 4 folds for each of 108 candidates, totalling 432 fits
    




    {'metric': 'manhattan', 'n_neighbors': 11, 'weights': 'distance'}



#### Evaluation Criteria

The KNN classification model is fit, with the best parameters.


```python
# best hyperparameters suppied as fitting parameters
knncv_knn = KNeighborsClassifier(**gsearchcv_knn.best_params_)
knncv_knn.fit(X_train, y_train)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>KNeighborsClassifier(metric=&#x27;manhattan&#x27;, n_neighbors=11, weights=&#x27;distance&#x27;)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;KNeighborsClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.neighbors.KNeighborsClassifier.html">?<span>Documentation for KNeighborsClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>KNeighborsClassifier(metric=&#x27;manhattan&#x27;, n_neighbors=11, weights=&#x27;distance&#x27;)</pre></div> </div></div></div></div>



#### Model Evaluation


```python

```


```python
# prediction
y_hat_knn = knncv_knn.predict(X_train)
```


```python
accuracy_knn_train = accuracy_score(y_train, y_hat_knn)
print('knn: Training Data Set Accuracy: ', accuracy_knn_train)
```

    knn: Training Data Set Accuracy:  0.9991087344028521
    


```python
# Confusion Matrix train data
cm_knn = confusion_matrix(y_train, y_hat_knn)
print(cm_knn)
```

    [[2027    0]
     [   3 1336]]
    


```python
from sklearn.metrics import classification_report
print(classification_report(y_train, y_hat_knn, target_names = ['0', '1']))
```

                  precision    recall  f1-score   support
    
               0       1.00      1.00      1.00      2027
               1       1.00      1.00      1.00      1339
    
        accuracy                           1.00      3366
       macro avg       1.00      1.00      1.00      3366
    weighted avg       1.00      1.00      1.00      3366
    
    


```python
y_knn = knncv_knn.predict(X_test)
accuracy_knn_test = accuracy_score(y_test, y_knn)
print('knn: Testing set accuracy: ', accuracy_knn_test)
```

    knn: Testing set accuracy:  0.9135071090047393
    


```python
print(classification_report(y_test, y_knn, target_names = ['0', '1']))
```

                  precision    recall  f1-score   support
    
               0       0.90      0.96      0.93       504
               1       0.93      0.84      0.89       340
    
        accuracy                           0.91       844
       macro avg       0.92      0.90      0.91       844
    weighted avg       0.91      0.91      0.91       844
    
    

### Decision Tree


```python
from sklearn.tree import DecisionTreeClassifier
```

The Decision Tree model is initialised, by the _DecisionTreeClassifier()_ method of scikit learn module. Hyperparameter tuning or optimization is undertaken to choosing a set of optimal hyperparameters for the Decision Tree learning on parameters: 

1. The criterio argument supplied with "gini" or "entropy", that measures the quality of splits.
2. The maximum depth of the decision tree.
3. The maximum number of leaf nodes to grow a tree.

Other values passed to the other parameters are learned over the course of training the model. A Decision Tree Classifier model is then fit, with the best parameters.


```python
# Hyperparameter tuning
param_decision_tree = [{'criterion':["gini", "entropy"],
          'max_depth': list(range(2, 20)),'max_leaf_nodes': list(range(2, 50))}]
grid_search_decision_tree = GridSearchCV(
    DecisionTreeClassifier(random_state=12345), param_decision_tree, verbose=1, cv=4, 
    n_jobs=-1, scoring = "accuracy")
```

#### Evaluation Criteria


```python
# Decision Trees fitting and prediction
grid_search_decision_tree.fit(X_train, y_train)
# best hyperparameter
grid_search_decision_tree.best_estimator_
```

    Fitting 4 folds for each of 1728 candidates, totalling 6912 fits
    




<style>#sk-container-id-2 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: black;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-2 {
  color: var(--sklearn-color-text);
}

#sk-container-id-2 pre {
  padding: 0;
}

#sk-container-id-2 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-2 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-2 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-2 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-2 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-2 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-2 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-2 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-2 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-2 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-2 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-2 label.sk-toggleable__label {
  cursor: pointer;
  display: block;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
}

#sk-container-id-2 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-2 div.sk-toggleable__content {
  max-height: 0;
  max-width: 0;
  overflow: hidden;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  max-height: 200px;
  max-width: 100%;
  overflow: auto;
}

#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-2 div.sk-label label.sk-toggleable__label,
#sk-container-id-2 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-2 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-2 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-2 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-2 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-2 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-2 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-2 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 1ex;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-2 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-2 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-2 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-2 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}
</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeClassifier(criterion=&#x27;entropy&#x27;, max_depth=9, max_leaf_nodes=46,
                       random_state=12345)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label fitted sk-toggleable__label-arrow fitted">&nbsp;&nbsp;DecisionTreeClassifier<a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.5/modules/generated/sklearn.tree.DecisionTreeClassifier.html">?<span>Documentation for DecisionTreeClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></label><div class="sk-toggleable__content fitted"><pre>DecisionTreeClassifier(criterion=&#x27;entropy&#x27;, max_depth=9, max_leaf_nodes=46,
                       random_state=12345)</pre></div> </div></div></div></div>



The Decision Tree classification model is fit, with the best parameters.

#### Model Evaluation


```python
y_pred_dec_tree = grid_search_decision_tree.predict(X_train)
accuracy_dec_tree_train = accuracy_score(y_train, y_pred_dec_tree)
print('Decision Tree: Training set accuracy: ', accuracy_dec_tree_train)
```

    Decision Tree: Training set accuracy:  0.9447415329768271
    


```python
cm_dt = confusion_matrix(y_train, y_pred_dec_tree)
print(cm_dt)
```

    [[1959   68]
     [ 118 1221]]
    


```python
print(classification_report(y_train, y_pred_dec_tree, target_names = ['0','1']))
```

                  precision    recall  f1-score   support
    
               0       0.94      0.97      0.95      2027
               1       0.95      0.91      0.93      1339
    
        accuracy                           0.94      3366
       macro avg       0.95      0.94      0.94      3366
    weighted avg       0.94      0.94      0.94      3366
    
    


```python
y_dec_tree = grid_search_decision_tree.predict(X_test)
accuracy_dec_tree_test = accuracy_score(y_test, y_dec_tree)
print('Decision Tree: Test set accuracy: ', accuracy_dec_tree_test)
```

    Decision Tree: Test set accuracy:  0.9312796208530806
    


```python
print(classification_report(y_test, y_dec_tree, target_names = ['0','1']))
```

                  precision    recall  f1-score   support
    
               0       0.93      0.96      0.94       504
               1       0.94      0.89      0.91       340
    
        accuracy                           0.93       844
       macro avg       0.93      0.92      0.93       844
    weighted avg       0.93      0.93      0.93       844
    
    


```python

```

# Experimental Results and Model Comparison

Model comparison are based on the accuracy, the rate at which a model correctly classifies the spam email as spam and non-spam as non-spam. 

1. On the train data, the KNN model performs better as compared to the Decision Tree classifier, with both performing fairly better at 99% and 94.5% rates respectively.
2. On the test data, the Decision Tree Classifier model performs slightly better compared to the KNN Classifier, with both performing fairly better at 93% and 91% rates respectively.
3. Missclassification rates are at a low at 8.6% and 6.9% for KNN and Decision Tree Classifier respectively on the test data.
4. Missclassification rates are at a low at 0% and 0.6% for KNN and Decision Tree Classifier respectively on the train data.
5. The ROC AUC measures the separation existing between classes of the binary classifier, with AUC values on test data for KNN and Decision Tree classifiers at 0.96 and 0.97 respectively.


The KNN model outperforms the Decision Tree for train data set, but slightly lower on test data set. The AUC value of Decision Classifier is higher, but both models are better of to distinguish the positive and negative classes and as such is classifying the email data as spam or not spam.


```python
from sklearn.metrics import roc_auc_score

y_knn_proba = knncv_knn.predict_proba(X_test)[:,1]
y_dec_tree_proba = grid_search_decision_tree.predict_proba(X_test)[:,1]
```


```python
from sklearn.metrics import roc_curve
from sklearn.metrics import RocCurveDisplay
def plot_roc_curve(y_real, y_pred, title = ''):
    fpr, tpr, _ = roc_curve(y_real, y_pred)
    roc_display = RocCurveDisplay(fpr=fpr, tpr=tpr).plot()
    roc_display.figure_.set_size_inches(5,5)
    plt.plot([0, 1], [0, 1], color = 'g')
    plt.title(title)
# Plots the ROC curve using the sklearn methods - Good plot
plot_roc_curve(y_test, y_knn_proba, title = 'KNN')
plot_roc_curve(y_test, y_dec_tree_proba, title = 'Decision Tree')
```


    
![png](output_99_0.png)
    



    
![png](output_99_1.png)
    



```python
pd.DataFrame(
    [
        ['kNN', 
         accuracy_knn_train, accuracy_knn_test, 
         1-accuracy_knn_train, 1-accuracy_knn_test,  
         roc_auc_score(y_test, y_knn_proba)],
        ['Decision Tree', 
         accuracy_dec_tree_train, accuracy_dec_tree_test, 
         1-accuracy_dec_tree_train, 1-accuracy_dec_tree_test, 
         roc_auc_score(y_test, y_dec_tree_proba)]
    ], columns = ['Model',
                  'Train Set: Accuracy','Test Set: Accuracy', 
                  'Train Set: misclassification_error',
                  'Test Set: misclassification_error',
                 'Test Data: Area Under the Curve (auc_score)'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Train Set: Accuracy</th>
      <th>Test Set: Accuracy</th>
      <th>Train Set: misclassification_error</th>
      <th>Test Set: misclassification_error</th>
      <th>Test Data: Area Under the Curve (auc_score)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>kNN</td>
      <td>0.999109</td>
      <td>0.913507</td>
      <td>0.000891</td>
      <td>0.086493</td>
      <td>0.960312</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Decision Tree</td>
      <td>0.944742</td>
      <td>0.931280</td>
      <td>0.055258</td>
      <td>0.068720</td>
      <td>0.970130</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

# Limitations and Possible Enhancements

Limitations

1. The data is based on frequency of words, characters and capitalization, with certain words being more prone to good non-spam emails being mimicked within the spam emails to escape the classification model scrutiny in real case scenarios, which in effect will have a impact in the evaluation of the model.


Possible Enhancements

1. The analysis is more of inclined towards ensuring that more and more good emails are flagged as good, while spam emails are classified as spam. However, over time, semantics change and spam email words and frequencies evolve, as such it is imperative when dealing with spam classification to take into consideration changes in semantics and their inclusion into spam classification models.
2. The hypertuning parameters used within our analysis are basic, as such extension to more data centric parameters would improve perfomance interms of better classification.


```python

```


```python

```


```python

```
